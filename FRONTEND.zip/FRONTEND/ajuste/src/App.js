import React from 'react';
import './App.css';
import Generator from './components/Generator';

function App() {
    return (
        <div className="App">
            <Generator />
        </div>
    );
}

export default App;
